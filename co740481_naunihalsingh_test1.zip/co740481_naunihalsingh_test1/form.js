function check(form)
{
var u1 = document.getElementById("user");
var p1 = document.getElementById("enter");

if(u1.value == "naunihal" && p1.value == "singh")
{
  window.open("login.html");
  return true;
}
else {
  alert("not ok");
  return false;
}
}
function validatePrice(){
  var amount = document.getElementById("amount").value;


  if(1 > 0 ){
    if (isNaN(amount)){
      alert("Enter Valid Amount");
    }
    else{
        //alert(price);
        if(amount > 2000){
            alert("Insufficient Balance");
        }
        else if(amount < 0){
            alert("Enter valid amount");
        }
        else{
            var balance = 2000 - amount;
            //alert(balance);
            var updatedBalance =  document.getElementById("final");
            updatedBalance.value = balance;
        }
    }
  }
  else{
    alert("Transfer should be made to a different account");
  }

}
